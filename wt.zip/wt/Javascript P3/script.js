function issueBook() {
    const title = document.getElementById('bookTitle').value.trim();
    const student = document.getElementById('studentName').value.trim();
    const list = document.getElementById('bookList');

    if (title === "" || student === "") {
        alert("Please fill in both fields.");
        return;
    }

    // Create list item
    const li = document.createElement('li');
    li.innerHTML = `<span><strong>${title}</strong> - Issued to: ${student}</span>`;

    // Create delete/return button
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Return';
    deleteBtn.className = 'delete-btn';
    deleteBtn.onclick = function () {
        list.removeChild(li);
    };

    li.appendChild(deleteBtn);
    list.appendChild(li);

    // Clear input fields
    document.getElementById('bookTitle').value = '';
    document.getElementById('studentName').value = '';
}
