
document.addEventListener('DOMContentLoaded', () => {
    
    // Select the button by its ID
    const button = document.getElementById('actionBtn');

    // Add a click event listener to the button
    button.addEventListener('click', () => {
        // Change the background color of the body
        document.body.style.backgroundColor = '#e0f7fa';
        
        // Show an alert message
        alert('Hello! Your external JavaScript is working perfectly!');
    });
});